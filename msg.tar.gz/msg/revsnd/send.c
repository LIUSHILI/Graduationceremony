#include<stdio.h>

#include<stdlib.h>

#include<string.h>

#include<sys/types.h>

#include<sys/ipc.h>

#include<sys/msg.h>

struct buf_msg
{

	long type;

	char mtext[512];

};

int main()

{

        struct buf_msg my_msg;

        int msg_id;

        key_t key;

        key = ftok("/usr/local", 1);

        if(key == -1)

                key = 1234;

        msg_id = msgget(key, IPC_CREAT|0600);

        if(msg_id == -1)

        {

                perror("error msgget\n");

                return -1;

        }

        my_msg.type = 1;

        memset(my_msg.mtext, 0, sizeof(my_msg.mtext));

       // strcpy(my_msg.mtext, "abcdefghijklmnopqresuvwxyz");
	   printf("plesse inout the message:\n");
	   if((fgets((&my_msg)->mtext,512,stdin)) == NULL)
	   {
		 puts("no message");
		 exit(0);
	   }

        if(msgsnd(msg_id, (void *)&my_msg, (size_t)strlen(my_msg.mtext), IPC_NOWAIT))

        {

                perror("error msgsnd\n");

                return  -1;

        }

        system("ipcs -q");

        sleep(20);

        msgctl(msg_id, IPC_RMID, NULL);

        return 0;

}