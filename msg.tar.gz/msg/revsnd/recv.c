#include<stdio.h>

#include<stdlib.h>

#include<string.h>

#include<sys/types.h>

#include<sys/ipc.h>

#include<sys/msg.h>

struct buf_msg{

long type;

char mtext[512];

};

int main()

{

        struct buf_msg my_msg;

        int msg_id;

        key_t key;

        int len;

        key = ftok("/usr/local", 1);

        if(key == -1)

                key = 1234;

        msg_id = msgget(key, IPC_CREAT|0600);

        if(msg_id == -1)

        {

                perror("msgget error\n");

                return -1;

        }

        len = msgrcv(msg_id, (void *)&my_msg, sizeof(my_msg.mtext), 0, 0);

        if(len ==-1)

        {

                perror("error msgrcv\n");

        }

        printf("type is %ld \nmtext is %s\n", my_msg.type, my_msg.mtext);

        system("ipcs -q ");

        sleep(20);

        system("ipcs -q");

        return 0;

}