#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/msg.h>
#include <sys/ipc.h>
#include <unistd.h>
struct msgmbuf
{
	 long msg_type;
	 char msg_text[512];
};
int main()
{
	 int qid;
	 key_t key;
	 int len;
	 
	 struct msgmbuf msg;
	 //if ((key = ftok((key_t)1235, 'a')) == -1)
	 //{
	 // perror("creat key error");
	 // exit(1);
	// }
	 
	 if ((qid = msgget((key_t)1234, IPC_CREAT | 0666)) == -1) //������Ϣ
	 {
	  perror("creat message queue erro");
	  exit(1);
	 }
	 
	 printf("creat , open queue qid is %d\n", qid);
	 if(fork() == 0)
	 {
		//�����̿ռ�
		 puts("This is parent process\n please input message to add to queue\n");
		 if ((fgets((&msg)->msg_text, 512, stdin)) == NULL)
		 {
		  puts("no message");
		  exit(1);
		 }
		 
		 msg.msg_type = getpid();
		 len = strlen(msg.msg_text);
		 printf("send message\n"); 
		 
		 if ((msgsnd(qid, &msg, len, 0)) < 0)
		 {
		  perror("add message error");
		  exit(1);
		 }
		 else
		 printf("send message :ok\n");
	 } 
	 else
	 {
		//�ӽ��̿ռ�
		 puts("This is children process\n");
		 if ((msgrcv(qid, &msg, 512, 0, 0)) < 0)
		 {
		  perror("read message error");
		  exit(1);
		 }
		 else
		 printf("read message: ok\n");
		 
		 printf("read message is: %s\n", (&msg)->msg_text);
		 
		 if ((msgctl(qid, IPC_RMID, NULL)) < 0)
		 {
		  perror("delete message error");
		  exit(1);
		 }
	 }
		 exit(0);
}